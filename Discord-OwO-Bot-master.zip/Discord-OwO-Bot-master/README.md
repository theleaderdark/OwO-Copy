# Discord-OwO-Bot
[![Discord Bots](https://discordbots.org/api/widget/status/408785106942164992.svg)](https://discordbots.org/bot/408785106942164992)  [![Discord Bots](https://discordbots.org/api/widget/servers/408785106942164992.svg)](https://discordbots.org/bot/408785106942164992)  [![Discord Bots](https://discordbots.org/api/widget/lib/408785106942164992.svg)](https://discordbots.org/bot/408785106942164992)

A fun bot for you Discord! Earn virtual cowoncy to hunt and battle animals! Keep track of your owo count! Climb the rankings!

[OwO Bot Invite Link](https://discordapp.com/api/oauth2/authorize?client_id=408785106942164992&permissions=0&scope=bot)
[OwO Bot Server Link](https://discord.gg/VKesv7J)

## Commands
| Catagory | Commands |
| --- | --- |
| Rankings | `top` `my` |
| Economy | `cowoncy` `give` `daily` `vote` |
| Animals | `zoo` `hunt` `sell` `battle` `pets` `inv` `shop` `equip` `buy` `autohunt` |
| Gambling | `slots` `coinflip` `lottery` `blackjack` |
| Fun | `8b` `define` `gif` `pic` `translate` |
| Social | `cookies` `ship` `pray` `curse` |
| Emotes | `blush` `cry` `dance` `lewd` `pout` `shrug` `sleepy` `smile` `smug` `thumbsup` `wag` `thinking` `triggered` `teehee` `deredere` `thonking` `scoff` `happy` `thumbs` `grin` |
| Actions | `cuddle` `hug` `insult` `kiss` `lick` `nom` `pat` `poke` `slap` `stare` `highfive` `bite` `greet` `punch` `handholding` `tickle` `kill` `hold` `pats` `wave` `boop` |
| Utility | `feedback` `ping` `stats` `link` `guildlink` `disable` `censor` `patreon` `help` |
