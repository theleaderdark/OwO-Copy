/**
 * Checks for macros
 */
exports.check = function(msg,command,callback){
	//Make an algorithm to check for bot/macro users here
	if(true){callback();return;}
}
